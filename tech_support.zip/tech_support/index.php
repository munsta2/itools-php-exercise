<?php include_once 'view/header.php'; ?>
<head>
    <link rel="stylesheet" type="text/css"href="main.css">
</head>
<main>
    <nav>
        
    <h2>Main Menu</h2>
    <ul>
        <li><a href="admin_login_manager" >Administrators</a></li>
        <li><a href="tech_login_manager">Technicians</a></li>
        <li><a href="product_register">Customers</a></li>
    </ul>

    
    </nav>
</section>
<?php include_once 'view/footer.php'; ?>