<?php include '../view/header.php' ?>
<main>
    <h1>Assign Incident</h1>
    <p>This incident has been assigned to a technician</p>
    <a href=".">Select another incident</a>
</main>
<?php include '../view/footer.php' ?>