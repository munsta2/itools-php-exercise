<?php include '../view/header.php'; ?>


<main>
    <h1>Create Incident</h1>
    <p>This incident was added to our database</p>
</main>

<?php include '../view/footer.php'; ?>