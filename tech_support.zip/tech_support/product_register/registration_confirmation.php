<?php include("../view/header.php"); ?>

<div id='main'>
    <h3>Register Product</h3>
    <p>Product (<?php echo $product_code; ?>) was registered successfully.</p>
</div>

<?php include("../view/footer.php"); ?>